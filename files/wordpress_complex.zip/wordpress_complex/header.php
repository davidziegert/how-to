<header>

	<div id="my-header-tag">
		<!-- Website Tags -->
		<span><?php bloginfo('name'); ?></span>
		<span><?php bloginfo('description'); ?></span>
	</div>

</header>