<main>

	<!-- Search -->
	<div id="my-search-form">	
		<?php get_search_form(); ?>
	</div>	
	
	<!-- Site Content -->
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<article id="my-content-tag">
			<h1><?php the_title(); ?></h1>
			<section><?php the_content(); ?></section>
		</article>
	<?php endwhile; endif; ?>

</main>