<nav>

	<!-- Menu -->
	<?php wp_nav_menu(array('theme_location' => 'my-main-menu', 'container_id' => 'my-main-menu')); ?>

</nav>