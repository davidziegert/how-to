<footer>

	<div id="my-breadcrumbs">
		<!-- Breadcrumbs -->
		<?php get_breadcrumb(); ?>	
	</div>	
	
	<!-- Last Update -->
	<div id="my-update-tag">
		<span>Last update: <?php the_modified_date() ?></span>	
	</div>
	
</footer>