<aside>

	<!-- Blog -->	
	<?php $the_query = new WP_Query( 'posts_per_page=4' ); ?>
		<?php while ($the_query -> have_posts()) : $the_query -> the_post(); ?>

			<div class="my-blog-tag">		
				<div class="my-blog-tag-img">
					<?php echo get_the_post_thumbnail(get_the_ID(), 'thumbnail'); ?>
				</div>
				<div class="my-blog-tag-text">
					<h3><?php the_title(); ?></h3>
					<p><?php echo wp_trim_words(get_the_content(), 20); ?> <a href="<?php the_permalink(); ?>">read more</a></p>
					<span><?php the_date('d.m.Y'); ?> | <?php the_category(', '); ?></span>
				</div>
			</div>
						  
	<?php endwhile; wp_reset_postdata(); ?>	

</aside>