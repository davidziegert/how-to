<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Site specific elements -->
	<title>Search | <?php bloginfo('name'); ?></title>

	<!-- CSS -->
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo get_bloginfo( 'template_directory' );?>/img/favicon.ico">
	<link rel="stylesheet" href="<?php echo get_bloginfo( 'template_directory' );?>/style.css">
	<link rel="stylesheet" href="<?php echo get_bloginfo( 'template_directory' );?>/css/reset.css">
	<link rel="stylesheet" href="<?php echo get_bloginfo( 'template_directory' );?>/css/custom.css">
	
	<!-- jQuery -->
	<script src="<?php echo get_bloginfo( 'template_directory' );?>/js/jquery-3.6.0.min.js"></script>
	<script src="<?php echo get_bloginfo( 'template_directory' );?>/js/custom.js"></script>
	
	<!-- Wordpress specific elements -->
	<?php wp_head(); ?>
</head>
<body>

	<!-- Head -->
	<?php include 'header.php'; ?>	

	<!-- Nav -->
	<?php include 'nav.php'; ?>	
	
	<!-- Main -->
	<main>
		<!-- Search -->
		<div id="my-search-form">	
			<?php get_search_form(); ?>
		</div>	
	
		<?php if (have_posts()) : ?>
		<p>Search results for: <strong><?php echo $s ?></strong></p>
		<div id="my-search-tag">
			<?php $i=1; while (have_posts()) : the_post(); ?>
			<div class="my-search-entry">
				<h3><?php the_title(); ?></h3>
				<p><?php echo wp_trim_words(get_the_content(), 20); ?> <a href="<?php the_permalink(); ?>">read more</a></p>
			</div>
			<?php $i++; endwhile; ?>
		</div>
		<?php else : ?>
		<p>Sorry, nothing found matching your search criteria!</p>
		<?php endif; ?>
		
	</main>	

	<!-- Aside -->
	<?php include 'sidebar.php'; ?>	

	<!-- Footer -->
	<?php include 'footer.php'; ?>	

	<!-- Wordpress specific elements -->
	<?php wp_footer(); ?>

</body>

</html>