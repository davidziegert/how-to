<footer>

	<!-- Categories -->
	<div id="my-category-tag">	
		<h3>Categories</h3>
		<ul>
			<?php wp_list_categories('orderby=name&order=ASC&title_li='); ?>
		</ul>
	</div>

	<!-- Archive -->
	<div id="my-archive-tag">	
		<h3>Archive</h3>
		<ul>
			<?php wp_get_archives('type=monthly'); ?>
		</ul>
	</div>	

	<!-- Sites -->
	<div id="my-sites-tag">	
		<h3>Sites</h3>
		<ul>
			<?php wp_list_pages('title_li=' . __('')); ?>
		</ul>
	</div>

</footer>