<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Site specific elements -->
	<title>404 | <?php bloginfo('name'); ?></title>

	<!-- CSS -->
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo get_bloginfo( 'template_directory' );?>/img/favicon.ico">
	<link rel="stylesheet" href="<?php echo get_bloginfo( 'template_directory' );?>/style.css">
	<link rel="stylesheet" href="<?php echo get_bloginfo( 'template_directory' );?>/css/reset.css">
	<link rel="stylesheet" href="<?php echo get_bloginfo( 'template_directory' );?>/css/custom.css">

	<!-- jQuery -->
	<script src="<?php echo get_bloginfo( 'template_directory' );?>/js/jquery-3.6.0.min.js"></script>
	<script src="<?php echo get_bloginfo( 'template_directory' );?>/js/custom.js"></script>

	<!-- Wordpress specific elements -->
	<?php wp_head(); ?>
</head>
<body>

	<div id="my-404-page">
		<h1>404 - Error</h1>
		<p>Sorry, but we can't find the page you are looking for.</p>
		<a href="<?php echo home_url(); ?>" rel="nofollow">Back</a>
	</div>

	<!-- Wordpress specific elements -->
	<?php wp_footer(); ?>

</body>

</html>