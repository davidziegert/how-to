<nav>

	<div id="my-breadcrumbs">
		<!-- Breadcrumbs -->
		<?php get_breadcrumb(); ?>
	</div>
	
	<!-- Search -->
	<div id="my-search-form">	
		<?php get_search_form(); ?>
	</div>

</nav>