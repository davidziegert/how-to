<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Simple extends Theme
{
    // Access plugin events in this class
}