<main>
    <div class="row">
        <!-- Breadcrumb-Navigation -->
        <?php insert_breadcrumbs(); ?>
        <hr>
    </div>
    <div class="row">
        <!-- If Post-Content exists then show -->
        <?php if (have_posts()):
            while (have_posts()):
                the_post(); ?>
                <article class="post-single">
                    <!-- Post-Title -->
                    <h1><?php the_title(); ?></h1>
                    <!-- Post-Content -->
                    <?php the_content(); ?>
                    <!-- Post-Author -->
                    <p class="post-author"><em>Author: <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a></em></p>
                    <!-- Post-Last-Update -->
                    <p class="post-update"><em>Last update: <?php the_modified_date() ?></em></p>
                    <!-- Post-Category -->
                    <p class="post-category"><em>Category: <?php the_category(', '); ?></em></p>
                </article>
            <?php endwhile;
        endif; ?>
    </div>
    <div class="row">
        <!-- Comments -->
        <?php include "comments.php"; ?>
    </div>
</main>