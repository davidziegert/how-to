<div class="comment-wrapper">
    <hr>

    <h3>Comments</h3>

    <!-- Block comments.php from direct calling -->
    <?php
    if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME'])):
        die('The "comments.php" file cannot be called directly.');
    endif;
    ?>

    <div class="comment-latest">
        <!-- Loop prints all Comments to this Post-ID -->
        <?php
        $args = array(
            'status' => 'approve',
            'post_id' => get_the_ID(),
        );

        $comments_query = new WP_Comment_Query;
        $comments = $comments_query->query($args);
        ?>

        <?php if ($comments): ?>
            <?php foreach ($comments as $comment): ?>
                <!-- Comment-Template -->
                <div class="comment-tag" id="comment-<?php comment_ID(); ?>">
                    <div class="comment-info">
                        <!-- Comment-Date | Comment-Time -->
                        <span><?php comment_date('j. F Y'); ?></span>
                        <!-- Comment-Time -->
                        <span><?php comment_time('H:i'); ?></span>
                        <!-- Comment-Author -->
                        <span><a href="<?php comment_author_url(); ?>" target="_blank" rel="noopener noreferrer"><?php comment_author(); ?></a></span>
                    </div>
                    <div class="comment-text">
                        <span><?php comment_text(); ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <?php echo "No comments found."; ?>
        <?php endif; ?>
    </div>

    <hr>

    <h3>Write a comment!</h3>
    <!-- Comment-Form-Template -->
    <form class="comment-form" action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post">
        <!-- Comment-Author-Name -->
        <label for="author">Author</label>
        <input type="text" name="author" id="author" size="20" tabindex="1" required />
        <!-- Comment-Author-EMail -->
        <label for="email">E-Mail</label>
        <input type="email" name="email" id="email" size="20" tabindex="2" required />
        <!-- Comment-Author-URL -->
        <label for="url">URL</label>
        <input type="url" name="url" id="url" size="20" tabindex="3" />
        <!-- Comment-Text -->
        <label for="comment">Comment</label>
        <textarea name="comment" id="comment" rows="10" tabindex="4" required></textarea>
        <input name="submit" type="submit" id="submit" value="Post" tabindex="5" />
        <input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>">
        <?php do_action('comment_form', $post->ID); ?>
    </form>
</div>