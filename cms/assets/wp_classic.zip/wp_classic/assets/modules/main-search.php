<main>
    <div class="row">
        <!-- Breadcrumb-Navigation -->
        <?php insert_breadcrumbs(); ?>
        <hr>
    </div>
    <div class="row">
        <div class="search-query">
            <!-- Print Search-Term -->
            <p>Search results for: <strong><?php echo $s ?></strong></p>
        </div>

        <?php if (have_posts()): ?>
            <!-- If have search match -->
            <div class="search-results">
                <!-- Loop prints all Sites and Post including the Search-Term -->
                <?php $i = 1;
                while (have_posts()):
                    the_post(); ?>
                    <details>
                        <!-- Title of Site or Post -->
                        <summary><?php the_title(); ?></summary>
                        <!-- Trimmed (20) Content of Post with Link -->
                        <p><?php echo wp_trim_words(get_the_content(), 20); ?></p>
                        <p><a href="<?php the_permalink(); ?>">read more</a></p>
                    </details>
                    <?php $i++;
                endwhile; ?>
            </div>
        <?php else: ?>
            <div class="search-fail">
                <!-- If no match found -->
                <p>Sorry, nothing found matching your search criteria!</p>
            </div>
        <?php endif; ?>
    </div>
</main>