<header>
    <div class="row">
        <div class="header-tag">
            <!-- Hamburger-Menu -->
            <button class="header-hamburger" id="hamburger" onclick="ToggleMenu()"><i class="bi bi-list"></i></button>
        </div>
        <div class="header-tag">
            <!-- Searchform -->
            <?php get_search_form(); ?>
        </div>
    </div>
    <div class="row">
        <div class="header-tag">
            <!-- Logo -->
            <img class="header-logo" src="<?php echo get_bloginfo('template_directory'); ?>/assets/images/logo.png" alt="No logo found!" loading="lazy" />
        </div>
        <div class="header-tag">
            <!-- Title / Subtitle -->
            <span class="header-title">Title</span>
            <span class="header-subtitle">Subtitle</span>
        </div>
    </div>
</header>