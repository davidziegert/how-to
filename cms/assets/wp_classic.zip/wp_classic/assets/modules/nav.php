<nav id="nav">
    <?php wp_nav_menu(array('theme_location' => 'my-main-menu', 'container_class' => 'main-menu')); ?>
</nav>