<main>
    <div class="row">
        <!-- Breadcrumb-Navigation -->
        <?php insert_breadcrumbs(); ?>
        <hr>
    </div>
    <div class="row">
        <?php
        $author_username = get_the_author_meta('user_nicename');
        $author_firstname = get_the_author_meta('first_name');
        $author_lastname = get_the_author_meta('last_name');
        $author_nickname = get_the_author_meta('nickname');
        $author_displayname = get_the_author_meta('display_name');
        $author_email = get_the_author_meta('user_email');
        $author_url = get_the_author_meta('user_url');
        $author_bio = get_the_author_meta('description');
        ?>

        <h1>Author</h1>

        <ul>
            <li>Username: <?php echo $author_username; ?></li>
            <li>First name: <?php echo $author_firstname; ?></li>
            <li>Last name: <?php echo $author_lastname; ?></li>
            <li>Nickname: <?php echo $author_nickname; ?></li>
            <li>Displayname: <?php echo $author_displayname; ?></li>
            <li>Email: <?php echo $author_email; ?></li>
            <li>Website: <?php echo $author_url; ?></li>
            <li>Biographical information: <?php echo $author_bio; ?></li>
        </ul>
    </div>
</main>