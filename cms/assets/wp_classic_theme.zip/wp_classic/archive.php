<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="robots" content="noindex, nofollow" />
    <meta name="mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-capable" content="yes" />

    <!-- Title Tag -->
    <title>
        <?php
        if (is_front_page()) {
            the_title();
            echo " - ";
            bloginfo('name');
        } else if (is_home()) {
            echo "Latest Posts - ";
            bloginfo('name');
        } else if (is_404()) {
            echo "404 - ";
            bloginfo('name');
        } else if (is_search()) {
            echo "Search - ";
            bloginfo('name');
        } else if (is_archive()) {
            echo "Archive - ";
            bloginfo('name');
        } else {
            the_title();
            echo " - ";
            bloginfo('name');
        }
        ?>
    </title>

    <!-- Site Meta Tags -->
    <meta name="author" content="<?php insert_author(); ?>">
    <meta name="description" content="<?php insert_meta_description(); ?>">
    <meta name="keywords" content="">

    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="<?php the_title(); ?>">
    <meta property="og:description" content="<?php insert_meta_description(); ?>">
    <meta property="og:image" content="<?php echo get_bloginfo('template_directory'); ?>/assets/images/opengraph.jpg">
    <meta property="og:site_name" content="<?php bloginfo('name'); ?>">
    <meta property="og:url" content="<?php echo the_permalink(); ?>">

    <!-- Icons -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo get_bloginfo('template_directory'); ?>/assets/images/favicon.ico">
    <link rel="apple-touch-icon" href="<?php echo get_bloginfo('template_directory'); ?>/assets/images/logo.png">

    <!-- Bootstrap-Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo get_bloginfo('template_directory'); ?>/assets/css/print.css" media="print" />
    <link rel="stylesheet" href="<?php echo get_bloginfo('template_directory'); ?>/assets/css/reset.css" media="screen" />
    <link rel="stylesheet" href="<?php echo get_bloginfo('template_directory'); ?>/assets/css/skeleton.css" media="screen" />
    <link rel="stylesheet" href="<?php echo get_bloginfo('template_directory'); ?>/assets/css/style.css" media="screen" />
    <link rel="stylesheet" href="<?php echo get_bloginfo('template_directory'); ?>/assets/css/theme.css" media="screen" />

    <!-- Wordpress specific elements -->
    <?php wp_head(); ?>
</head>

<body>
    <div class="wrapper">
        <!-- Header -->
        <?php include "assets/modules/header.php"; ?>

        <div class="content">
            <!-- Nav -->
            <?php include "assets/modules/nav.php"; ?>

            <!-- Main -->
            <?php include "assets/modules/main-archive.php"; ?>

            <!-- Aside -->
            <?php include "assets/modules/sidebar.php"; ?>
        </div>

        <!-- Footer -->
        <?php include "assets/modules/footer.php"; ?>
    </div>

    <!-- Scripts -->
    <script src="<?php echo get_bloginfo('template_directory'); ?>/assets/js/script.js"></script>

    <!-- WordPress-Specific-Elements -->
    <?php wp_footer(); ?>
</body>

</html>