<main>
    <div class="row">
        <h1>404 - Error</h1>
        <p>Sorry, but we can't find the page you are looking for.</p>
        <a href="<?php echo home_url(); ?>" rel="nofollow">Go Back</a>
    </div>
</main>