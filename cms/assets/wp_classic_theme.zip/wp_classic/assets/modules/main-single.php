<main>
    <div class="row">
        <!-- If Post-Content exists then show -->
        <?php if (have_posts()):
            while (have_posts()):
                the_post(); ?>
                <article class="post-single">
                    <!-- Post-Title -->
                    <h1><?php the_title(); ?></h1>
                    <!-- Post-Content -->
                    <?php the_content(); ?>
                    <!-- Post-Last-Update -->
                    <p class="post-update"><em>Last update: <?php the_modified_date() ?></em></p>
                    <!-- Post-Category -->
                    <p class="post-category"><em>Category: <?php the_category(', '); ?></em></p>
                </article>
            <?php endwhile;
        endif; ?>
    </div>
</main>