<footer>
    <div class="row">
        <div class="column">
            <span>Theme: Kirby v.1</span>
        </div>
        <div class="column">
            <button class="footer-scroller" id="scroller" onclick="GoTop()">Top</button>
        </div>
    </div>
</footer>
</div>

<!-- Scripts -->
<?= js('assets/js/script.js') ?>
</body>

</html>