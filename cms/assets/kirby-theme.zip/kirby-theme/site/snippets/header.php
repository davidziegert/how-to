<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="robots" content="noindex, nofollow" />
    <meta name="mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-capable" content="yes" />

    <!-- Title Tag -->
    <title><?= $page->title() ?> | <?= $site->title() ?></title>

    <!-- Site Meta Tags -->
    <meta name="author" content="<?= $site->author() ?>">
    <meta name="description" content="<?php echo str::excerpt($page->text(), 200, false) ?>">
    <meta name="keywords" content="<?= $site->keywords() ?>">

    <!-- Open Graph Meta Tags -->
    <meta property="og:site_name" content="<?= $site->title() ?>">
    <meta property="og:url" content="<?= $page->url() ?>">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?= $page->title() ?>">
    <meta property="og:description" content="<?php echo str::excerpt($page->text(), 200, false) ?>">

    <?php if ($asset = asset('assets/img/opengraph.jpg')): ?>
        <meta property="og:image" content="<?= $asset->url() ?>">
    <?php endif ?>

    <!-- Styles -->
    <?= css('assets/css/print.css', 'print') ?>
    <?= css('assets/css/reset.css') ?>
    <?= css('assets/css/skeleton.css') ?>
    <?= css('assets/css/style.css') ?>
    <?= css('assets/css/theme.css') ?>

    <!-- Icons -->
    <?php if ($asset = asset('assets/icons/favicon.svg')): ?>
        <link rel="shortcut icon" type="image/x-icon" href="<?= $asset->url() ?>">
        <link rel="apple-touch-icon" href="<?= $asset->url() ?>">
    <?php endif ?>
</head>

<body>
    <div class="wrapper">
        <header>
            <div class="row">
                <div class="column">
                    <?php if ($asset = asset('assets/img/logo.svg')): ?>
                        <img class="header-logo" src="<?= $asset->url() ?>" loading="lazy" />
                    <?php endif ?>
                    <span class="header-title"><?= $site->title() ?></span>
                    <span class="header-subtitle"><?= $site->subtitle() ?></span>
                </div>
                <div class="column">
                    <button class="header-hamburger" id="hamburger" onclick="ToggleMenu()">
                        <?php if ($kirby->language()->code() == 'de'): ?>Menü<?php endif ?>
                        <?php if ($kirby->language()->code() == 'en'): ?>Menu<?php endif ?>
                    </button>
                </div>
            </div>
        </header>