<main>
    <div class="row">
        <!-- TITLE -->
        <h1><?= $page->title() ?></h1>
        <!-- CONTENT -->
        <?= $page->text()->kirbytext() ?>
    </div>
</main>