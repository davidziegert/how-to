<?php $items = $pages->listed();
if ($items->isNotEmpty()): ?>
    <nav id="nav">
        <menu class="main-menu">
            <?php foreach ($items as $item): ?>
                <?php $children = $item->children()->listed(); ?>
                <?php if ($children->isEmpty()): ?>
                    <li <?php e($item->isActive(), ' class="menu-item current-page-item"') ?> class="menu-item">
                        <a href="<?= $item->url() ?>"><?= $item->title()->html() ?></a>
                    </li>
                <?php endif ?>
                <?php if ($children->isNotEmpty()): ?>
                    <li <?php e($item->isActive(), ' class="menu-item menu-item-has-children current-page-item"') ?> class="menu-item menu-item-has-children">
                        <a href="<?= $item->url() ?>"><?= $item->title()->html() ?></a>
                        <ul class="sub-menu">
                            <?php foreach ($children as $child): ?>
                                <?php $grandchildren = $child->children()->listed(); ?>
                                <?php if ($grandchildren->isEmpty()): ?>
                                    <li <?php e($child->isActive(), ' class="menu-item current-page-item"') ?> class="menu-item">
                                        <a href="<?= $child->url() ?>"><?= $child->title()->html() ?></a>
                                    </li>
                                <?php endif ?>
                                <?php if ($grandchildren->isNotEmpty()): ?>
                                    <li <?php e($child->isActive(), ' class="menu-item menu-item-has-children current-page-item"') ?> class="menu-item menu-item-has-children">
                                        <a href="<?= $child->url() ?>"><?= $child->title()->html() ?></a>
                                        <ul class="sub-menu">
                                            <?php foreach ($grandchildren as $grandchild): ?>
                                                <li <?php e($grandchild->isActive(), ' class="menu-item current-page-item"') ?> class="menu-item">
                                                    <a href="<?= $grandchild->url() ?>"><?= $grandchild->title()->html() ?></a>
                                                </li>
                                            <?php endforeach ?>
                                        </ul>
                                    </li>
                                <?php endif ?>
                            <?php endforeach ?>
                        </ul>
                    </li>
                <?php endif ?>
            <?php endforeach ?>
        </menu>
    </nav>
<?php endif ?>
