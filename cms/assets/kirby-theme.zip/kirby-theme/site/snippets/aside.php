<aside>
    <div class="row">
        <div class="column">
            <div class="language-box">
                <!-- LANGUAGES -->
                <?php if ($kirby->language()->code() == 'de'): ?>
                    <p>Bitte Spräche wählen:</p>
                <?php endif ?>
                <?php if ($kirby->language()->code() == 'en'): ?>
                    <p>Please select language:</p>
                <?php endif ?>
                <ul>
                    <?php foreach ($kirby->languages() as $language): ?>
                        <li<?php e($kirby->language() == $language, ' class="active"') ?>><a href="<?= $page->url($language->code()) ?>" hreflang="<?php echo $language->code() ?>"><?= html($language->name()) ?></a></li>
                        <?php endforeach ?>
                </ul>
            </div>
        </div>
        <div class="column">
            <div class="search-box">
                <!-- SEARCH -->
                <form action="<?= page('search')->url() ?>">
                    <?php if ($kirby->language()->code() == 'de'): ?>
                        <input type="search" aria-label="Suche" name="q" value="">
                        <input type="submit" value="Suche">
                    <?php endif ?>
                    <?php if ($kirby->language()->code() == 'en'): ?>
                        <input type="search" aria-label="Search" name="q" value="">
                        <input type="submit" value="Search">
                    <?php endif ?>
                </form>
            </div>
        </div>
    </div>
</aside>