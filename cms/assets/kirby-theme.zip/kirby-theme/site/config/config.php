<?php

return [
  'languages' => true,
  'debug' => false,
];

