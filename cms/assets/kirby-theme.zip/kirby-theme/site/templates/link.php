<?php go($page->link(), 301) ?>
