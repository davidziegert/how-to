<?php snippet('header') ?>
<?php snippet('nav') ?>

<main>
    <!-- TITLE -->
    <h1><?= $page->title() ?></h1>

    <!-- SEARCH-RESULTS -->
    <?php if (count($results) == 0): ?>
        <?php if ($kirby->language()->code() == 'de'): ?>Es tut uns leid, es wurde nichts gefunden, das Ihren Suchkriterien entspricht!<?php endif ?>
        <?php if ($kirby->language()->code() == 'en'): ?>We're sorry, nothing was found that matches your search criteria!<?php endif ?>
    <?php endif ?>

    <?php foreach ($results as $result): ?>
        <details>
            <summary><?= $result->title() ?></summary>
            <p>
                <?php echo str::excerpt($result->text()->kirbytext(), 250, true) ?>
            </p>
            <p>
                <a href="<?= $result->url() ?>">
                    <?php if ($kirby->language()->code() == 'de'): ?>weiterlesen<?php endif ?>
                    <?php if ($kirby->language()->code() == 'en'): ?>read more<?php endif ?>
                </a>
            </p>
        </details>
    <?php endforeach ?>
</main>

<?php snippet('aside') ?>
<?php snippet('footer') ?>
