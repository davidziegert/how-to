<?php snippet('header') ?>
<?php snippet('nav') ?>

<main>
    <!-- TITLE -->
    <h1><?= $page->title() ?></h1>

    <!-- CONTENT -->
    <?= $page->text()->kirbytext() ?>
</main>

<?php snippet('aside') ?>
<?php snippet('footer') ?>
